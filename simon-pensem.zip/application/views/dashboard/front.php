<div class="row">
	<div class="col-sm-12">
		<div class="well">
			<h1><?php echo date('F d, Y'); ?></h1>
			<h3>Selamat datang <strong><?php echo $this->session->userdata('SESS_NAMA_USER'); ?></strong></h3>
		</div>
	</div>
</div>